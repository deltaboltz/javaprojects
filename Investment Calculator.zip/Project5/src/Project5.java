import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import java.lang.Math;
public class Project5 extends Application 
{
 
	 public static void main(String[] args) 
	 {
		 launch(args);
	 }
	@Override
	public void start(Stage primaryStage) 
	{

		FlowPane pane = new FlowPane();
		pane.setHgap(500);
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(5));
		TextField tf1 = new TextField();
		TextField tf2 = new TextField();
		TextField tf3 = new TextField();
		TextField finalWorth = new TextField();
		finalWorth.setEditable(false);

		tf1.setPrefColumnCount(5);
		tf2.setPrefColumnCount(5);
		tf3.setPrefColumnCount(5);
		finalWorth.setPrefColumnCount(5);
		

		Label l1 = new Label("Money Used in Investment ");
		Label l2 = new Label("Years ");
		Label l3 = new Label("Annual Interest Rate ");
		Label l4 = new Label("Final Financial Worth ");
		
		
		BorderPane.setAlignment(l1, Pos.CENTER_LEFT);

		pane.getChildren().addAll(l1, tf1, l2, tf2, l3, tf3, l4, finalWorth);

		HBox hBox = new HBox();
		Button calculate = new Button("Calculate");
		hBox.setAlignment(Pos.BOTTOM_RIGHT);
		hBox.getChildren().addAll(calculate);

		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(pane);
		borderPane.setBottom(hBox);
		borderPane.setAlignment(hBox,Pos.BOTTOM_RIGHT);

		Scene scene = new Scene(borderPane, 350, 250);
		primaryStage.setTitle("Financial Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();

		calculate.setOnAction(e -> 
		{
			finalWorth.setText(String.format("$%.2f", ((Double.parseDouble(tf1.getText()) * Math.pow(1 + (Double.parseDouble(tf3.getText()) / 1200), Double.parseDouble(tf2.getText()) * 12 ) ))));
			
		});
	}


} 