
public class TestAccount 
{

	public static void main(String[] args) 
	{
		//Create a new object of the Account class
		//Use the overloaded constructor to create the ID and the starting balance
		Account newAccount = new Account(1122, 20000);
		
		//Use the setAnnualInterest method to set the interest rate to 4.5%
		//Don't worry about this being a percentage, that will be worked out with the dividing of 100
		newAccount.setAnnualInterest(4.5);
		
		//Use the withdraw method to withdraw a desired amount
		newAccount.withdraw(2500.00);
		
		//Use the deposit method to deposit a desried ammount
		newAccount.deposit(3000.00);
		
		//Now use your getter methods to print off the:
		//Balance, Monthly Interest that you will accumalate, and the date the account was created
		System.out.println("The current balance is: " + newAccount.getBalance());
		System.out.println("The monthly interest is: " + newAccount.getMonthlyInterest());
		System.out.println("The account was created on: " + newAccount.getDate());
	}

}
