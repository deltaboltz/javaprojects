import java.util.Date;

public class Account 
{
	//Create your desired data fields
	private int id;
	private double balance;
	private double annualInterest;
	private Date dateCreated;
	
	
	


Account()
{
	//Use the default constructor to make every aspect of the account set to zero
	
	id = 0;
	balance = 0;
	annualInterest = 0;
	
	//Make sure to get the date and time of this acount creation
	dateCreated = new Date();
}

Account(int accountID, double initialBalance)
{
	//Use an overloaded constructor to create an account with the users account
	//ID and the balance
	
	//Do not set the annual interest rate just yet, that will be used with a setter method
	
	id = accountID;
	balance = initialBalance;
	
	//Make sure to get the time and date of this account creation
	dateCreated = new Date();

}

public void setID(int accountID)
{
	//Set the private id data number
	id = accountID;
}

public void setBalance(double accountBalance)
{
	//Set the private balance data field amount
	balance = accountBalance;
}

public void setAnnualInterest(double accountInterest)
{
	//Set the private annual interest data field number
	annualInterest = accountInterest;
}

public Date getDate()
{
	//Use the get the date that the called acount was made on
	return dateCreated;
}

public double getMonthlyInterestRate()
{
	//Create a monthly variable
	double monthly;
	
	//Divide the annual by 100 to get the decimal then divide by 12(months)
	monthly = (annualInterest / 100) / 12;
	
	//Now return the new monthly
	return monthly;
}

public double getMonthlyInterest()
{
	//Create a monthly interest variable
	double monthlyInterest;
	
	//Set it = to the balance times the monthly interest that you get from the getter method (same formula)
	monthlyInterest = balance * ((annualInterest / 100) / 12);
	return monthlyInterest;
}

public double withdraw(double withdrawAmmount)
{
	//Set balance to minus the ammount the user wishes to withdraw
	balance -= withdrawAmmount;
	return balance;
}

public double deposit(double depositAmmount)
{
	//Set the balance plus to the ammount the user wishes to deposit
	balance += depositAmmount;
	return balance;
}
public double getBalance()
{
	//Simply return the balance of the called account
	return balance;
}

}